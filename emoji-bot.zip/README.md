# 💩 Emoji Bot

Bot Telegram che conta le 💩 di ogni membro del gruppo e pubblica la classifica il 1° di ogni mese.

## Setup su Render

1. Fai il fork di questo repository su GitHub
2. Vai su [render.com](https://render.com) e crea un account
3. Clicca **New** → **Blueprint** e collega il tuo repository
4. Aggiungi la variabile d'ambiente `TOKEN` con il token del tuo bot
5. Clicca **Deploy** — il bot è live!

## Variabili d'ambiente

| Variabile | Descrizione |
|-----------|-------------|
| `TOKEN`   | Il token del bot ottenuto da @BotFather su Telegram |

## Come aggiungere il bot al gruppo

1. Aggiungi il bot al tuo gruppo Telegram
2. Vai su @BotFather → `/setprivacy` → seleziona il bot → `Disable`
   (così il bot può leggere tutti i messaggi del gruppo)

## Funzionamento

- Il bot conta ogni 💩 inviata da ogni membro
- Il 1° di ogni mese alle 9:00 pubblica la classifica nel gruppo
- Dopo il report, i contatori vengono azzerati
