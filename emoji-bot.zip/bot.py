import json
import os
from datetime import datetime
from telegram import Update
from telegram.ext import Application, MessageHandler, filters, ContextTypes
from apscheduler.schedulers.asyncio import AsyncIOScheduler

TOKEN = os.environ.get("TOKEN")
EMOJI = "💩"
DB_FILE = "counts.json"

def load_data():
    if os.path.exists(DB_FILE):
        with open(DB_FILE) as f:
            return json.load(f)
    return {}

def save_data(data):
    with open(DB_FILE, "w") as f:
        json.dump(data, f)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.text:
        return

    count = msg.text.count(EMOJI)
    if count == 0:
        return

    chat_id = str(msg.chat_id)
    user = msg.from_user
    user_id = str(user.id)
    name = user.full_name

    data = load_data()
    if chat_id not in data:
        data[chat_id] = {}
    if user_id not in data[chat_id]:
        data[chat_id][user_id] = {"name": name, "count": 0}

    data[chat_id][user_id]["count"] += count
    data[chat_id][user_id]["name"] = name
    save_data(data)
    print(f"[{datetime.now()}] {name} ha usato {EMOJI} {count} volta/e (totale: {data[chat_id][user_id]['count']})")

async def send_monthly_report(app):
    data = load_data()
    month_num = datetime.now().month - 1 or 12
    month_name = datetime(2000, month_num, 1).strftime("%B")

    for chat_id, users in data.items():
        if not users:
            continue

        sorted_users = sorted(users.items(), key=lambda x: x[1]["count"], reverse=True)
        lines = [f"📊 *Classifica {EMOJI} — {month_name}*\n"]
        for i, (uid, info) in enumerate(sorted_users, 1):
            medal = ["🥇", "🥈", "🥉"][i-1] if i <= 3 else f"{i}."
            lines.append(f"{medal} {info['name']}: *{info['count']}* volte")

        await app.bot.send_message(
            chat_id=int(chat_id),
            text="\n".join(lines),
            parse_mode="Markdown"
        )
        print(f"[{datetime.now()}] Report mensile inviato al gruppo {chat_id}")

    # Reset contatori
    for chat_id in data:
        for uid in data[chat_id]:
            data[chat_id][uid]["count"] = 0
    save_data(data)

def main():
    if not TOKEN:
        raise ValueError("TOKEN non trovato! Aggiungilo come variabile d'ambiente su Render.")

    app = Application.builder().token(TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        send_monthly_report,
        trigger="cron",
        day=1, hour=9, minute=0,
        args=[app]
    )
    scheduler.start()

    print("✅ Bot avviato e in ascolto!")
    app.run_polling()

if __name__ == "__main__":
    main()
